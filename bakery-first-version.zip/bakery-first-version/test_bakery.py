"""Business-rule checks performed only on a temporary database copy."""
import shutil
import tempfile
import unittest
from pathlib import Path
import app

class BakeryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.original=app.DB
        app.DB=Path(self.tmp.name)/'bakery.db'
        if self.original.exists(): shutil.copy2(self.original,app.DB)
        # Build a pristine scenario on the copy, regardless of saved user decisions.
        with app.connect() as c:
            for row in c.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall():
                c.execute('DROP TABLE "'+row[0]+'"')
        app.init()
    def tearDown(self):
        app.DB=self.original
        self.tmp.cleanup()
    def decide(self,c,name,kind='accept'):
        m=c.execute('SELECT * FROM messages WHERE customer=? ORDER BY id LIMIT 1',(name,)).fetchone()
        app.action(c,dict(action=kind,id=m['id']))
    def test_import_and_idempotence(self):
        app.init()
        with app.connect() as c:
            self.assertEqual(c.execute('SELECT count(*) FROM orders').fetchone()[0],13)
            self.assertEqual(c.execute('SELECT count(*) FROM messages').fetchone()[0],25)
            self.assertEqual(len(app.state(c)['messages']),3)
    def test_notice_and_future(self):
        with app.connect() as c:
            with self.assertRaises(ValueError): self.decide(c,'Okafor')
            with self.assertRaises(ValueError): self.decide(c,'Reyes')
            self.decide(c,'Jasmine')
            self.assertEqual(app.usage(c,'2026-11-25'),3.5)
    def test_capacity_and_helper(self):
        with app.connect() as c:
            c.execute("UPDATE settings SET value='2026-11-26' WHERE key='today'")
            self.decide(c,'Moreau');self.decide(c,'Tan')
            with self.assertRaises(ValueError): self.decide(c,'Singh')
            app.action(c,dict(action='helper',day='2026-11-28'))
            self.decide(c,'Singh')
            self.assertEqual(app.usage(c,'2026-11-28'),9)

            with self.assertRaises(ValueError): app.action(c,dict(action='helper',day='2026-11-28'))
            with self.assertRaises(ValueError): app.action(c,dict(action='helper',day='2026-11-27'))
    def test_changes_and_cancellations(self):
        with app.connect() as c:
            c.execute("UPDATE settings SET value='2026-11-24' WHERE key='today'")
            self.decide(c,'Brown')
            self.assertEqual(app.usage(c,'2026-11-26'),5)
            c.execute("UPDATE settings SET value='2026-11-25' WHERE key='today'")
            self.decide(c,'Lam')
            c.execute("UPDATE settings SET value='2026-11-26' WHERE key='today'")
            m=c.execute("SELECT * FROM messages WHERE customer='Lam' AND kind='change'").fetchone()
            with self.assertRaises(ValueError): app.action(c,dict(action='accept',id=m['id']))
            self.assertEqual(c.execute("SELECT quantity FROM orders WHERE customer='Lam'").fetchone()[0],2)
    def test_forward_requires_decisions(self):
        with app.connect() as c:
            with self.assertRaises(ValueError): app.action(c,dict(action='day',day='2026-11-24'))
            for name in ('Jasmine','Okafor','Patel'): self.decide(c,name,'reject')
            app.action(c,dict(action='day',day='2026-11-24'))
            with self.assertRaises(ValueError): app.action(c,dict(action='day',day='2026-11-23'))

if __name__=='__main__': unittest.main()

"""Local bakery manager. Python standard library only."""
import csv
import datetime as dt
import html
import json
import re
import sqlite3
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = Path(__file__).resolve().parent
DB = ROOT / 'bakery.db'
DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']

class Connection(sqlite3.Connection):
    def __exit__(self, *args):
        try: return super().__exit__(*args)
        finally: self.close()

def connect():
    c = sqlite3.connect(DB, factory=Connection)
    c.row_factory = sqlite3.Row
    return c

def product(text):
    m = re.search(r'(\d+)\s+(dozen cupcakes|cakes?)', text, re.I)
    if not m: raise ValueError('Use a positive whole number of cakes or dozens of cupcakes.')
    q = int(m[1])
    if not 1 <= q <= 100: raise ValueError('Quantity must be between 1 and 100.')
    return ('cupcakes' if 'cupcake' in m[2].lower() else 'cake'), q

def date_text(text):
    m = re.search(r'(Nov|Dec)\s+(\d+)', text)
    if not m:
        m = re.search(r'(\d+)\s+(Nov|Dec)', text)
        return dt.date(2026,11 if m[2]=='Nov' else 12,int(m[1])).isoformat()
    return dt.date(2026,11 if m[1]=='Nov' else 12,int(m[2])).isoformat()

def init():
    with connect() as c:
        c.executescript('''CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY,customer TEXT,product TEXT,quantity INTEGER,pickup TEXT,status TEXT);
        CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY,day TEXT,customer TEXT,kind TEXT,product TEXT,quantity INTEGER,pickup TEXT,raw TEXT,status TEXT DEFAULT 'pending',note TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS helpers(day TEXT PRIMARY KEY);
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT);
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,day TEXT,detail TEXT);
        ''')
        if c.execute("SELECT 1 FROM settings WHERE key='initialized'").fetchone(): return
        for r in csv.DictReader((ROOT/'existing_orders.csv').read_text().splitlines()):
            p,q=product(r['item'])
            c.execute('INSERT INTO orders VALUES(?,?,?,?,?,?)',(int(r['order'][1:]),r['customer'],p,q,date_text(r['pickup_day']),'accepted'))
        for i,day in enumerate(DAYS):
            source=(ROOT/f'InstagramOrders_{day}.html').read_text()
            for raw in re.findall(r'<p class="message">(.*?)</p>',source,re.S):
                raw=html.unescape(raw)
                name,order,pickup=[line.split(':',1)[1].strip() for line in raw.splitlines()]
                kind='cancel' if order.lower()=='cancel' else 'change' if order.lower().startswith('change') else 'new'
                p,q=('',0) if kind=='cancel' else product(order)
                c.execute('INSERT INTO messages(day,customer,kind,product,quantity,pickup,raw) VALUES(?,?,?,?,?,?,?)',((dt.date(2026,11,23)+dt.timedelta(days=i)).isoformat(),name,kind,p,q,date_text(pickup),raw))
        c.executemany('INSERT INTO settings VALUES(?,?)',[('initialized','yes'),('today','2026-11-23')])

def hours(row): return row['quantity']*(0.5 if row['product']=='cupcakes' else 2)
def today(c): return c.execute("SELECT value FROM settings WHERE key='today'").fetchone()[0]
def usage(c,day): return sum(hours(r) for r in c.execute("SELECT * FROM orders WHERE pickup=? AND status='accepted'",(day,)))
def capacity(c,day): return 12 if c.execute('SELECT 1 FROM helpers WHERE day=?',(day,)).fetchone() else 8

def eligibility(c,m):
    if m['day'] > today(c): return 'This message has not arrived yet.',None
    # Notice is evaluated on the working day; message dates remain visible for audit.
    if (dt.date.fromisoformat(m['pickup'])-dt.date.fromisoformat(today(c))).days < 2: return 'Too late: two calendar days of notice are required.',None
    target=None
    if m['kind']!='new':
        matches=c.execute("SELECT * FROM orders WHERE lower(customer)=lower(?) AND pickup=? AND status='accepted'",(m['customer'],m['pickup'])).fetchall()
        if len(matches)!=1: return 'Needs review: exactly one accepted matching order is required.',None
        target=matches[0]
    required=0 if m['kind']=='cancel' else hours(m)
    total=usage(c,m['pickup'])-(hours(target) if target else 0)+required
    if total>capacity(c,m['pickup']): return f'Over capacity: would use {total:g} hours. Book a helper if eligible, or reject.',target
    return '',target

def state(c):
    now=today(c)
    messages=[]
    for r in c.execute('SELECT * FROM messages WHERE day<=? ORDER BY day,id',(now,)):
        m=dict(r);m['reason']=eligibility(c,r)[0] if r['status']=='pending' else r['note'];messages.append(m)
    calendar=[]
    for i in range(9):
        day=(dt.date(2026,11,23)+dt.timedelta(days=i)).isoformat()
        rows=c.execute("SELECT * FROM orders WHERE pickup=? AND status='accepted'",(day,)).fetchall()
        revenue=sum(r['quantity']*(40 if r['product']=='cupcakes' else 120) for r in rows)
        cap=capacity(c,day)
        calendar.append(dict(day=day,hours=usage(c,day),capacity=cap,revenue=revenue,helper=cap==12,net=revenue-(100 if cap==12 else 0)))
    return dict(today=now,messages=messages,calendar=calendar,orders=[dict(r) for r in c.execute('SELECT * FROM orders ORDER BY pickup,id')],audit=[dict(r) for r in c.execute('SELECT * FROM audit ORDER BY id DESC LIMIT 30')])

def action(c,a):
    now=today(c);kind=a['action']
    if kind=='day':
        day=a['day']
        if day<now or day>'2026-11-29': raise ValueError('Working days only move forward, through November 29.')
        dt.date.fromisoformat(day)
        if day>now and c.execute("SELECT 1 FROM messages WHERE day<=? AND status='pending'",(now,)).fetchone(): raise ValueError('Accept or reject the pending messages before advancing.')
        c.execute("UPDATE settings SET value=? WHERE key='today'",(day,));detail='Working day advanced to '+day
    elif kind=='helper':
        day=a['day']
        if (dt.date.fromisoformat(day)-dt.date.fromisoformat(now)).days<2: raise ValueError('Helpers need two calendar days of notice.')
        if not '2026-11-23'<=day<='2026-12-01': raise ValueError('Date outside this planning calendar.')
        if c.execute('SELECT 1 FROM helpers WHERE day=?',(day,)).fetchone(): raise ValueError('A helper is already booked.')
        c.execute('INSERT INTO helpers VALUES(?)',(day,));detail='Booked helper for '+day+' ($100)'
    elif kind in ('accept','reject'):
        m=c.execute('SELECT * FROM messages WHERE id=?',(int(a['id']),)).fetchone()
        if not m or m['status']!='pending' or m['day']>now: raise ValueError('Message is not available for a decision.')
        reason,target=eligibility(c,m)
        if kind=='accept':
            if reason: raise ValueError(reason)
            if m['kind']=='new': c.execute("INSERT INTO orders(customer,product,quantity,pickup,status) VALUES(?,?,?,?,'accepted')",(m['customer'],m['product'],m['quantity'],m['pickup']))
            elif m['kind']=='cancel': c.execute("UPDATE orders SET status='cancelled' WHERE id=?",(target['id'],))
            else: c.execute('UPDATE orders SET product=?,quantity=? WHERE id=?',(m['product'],m['quantity'],target['id']))
        note=reason if kind=='reject' and reason else 'Baker decision'
        c.execute('UPDATE messages SET status=?,note=? WHERE id=?',('accepted' if kind=='accept' else 'rejected',note,m['id']))
        detail=f"{kind.title()} message {m['id']}: {m['customer']} / {m['kind']} ({note})"
    else: raise ValueError('Unknown action.')
    c.execute('INSERT INTO audit(day,detail) VALUES(?,?)',(now,detail))

PAGE = '''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Butter & Batch · Bakery planner</title>
<style>
:root{--ink:#2f3530;--green:#345b48;--cream:#f7f4ed;--line:#deded2}*{box-sizing:border-box}body{margin:0;background:var(--cream);color:var(--ink);font:15px system-ui,sans-serif}header{background:var(--green);color:white;padding:30px 5%;display:flex;justify-content:space-between;align-items:center}h1{font:36px Georgia;margin:4px 0}header a{color:white}main{max-width:1350px;margin:30px auto;padding:0 24px}h2{font:27px Georgia}small,.muted{color:#60685f}.toolbar{display:flex;gap:12px;align-items:center;flex-wrap:wrap}.calendar{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin:22px 0}.card,.panel{background:#fff;border:1px solid var(--line);border-radius:12px;padding:18px}.card b{display:block;margin-bottom:10px}.card strong{font-size:23px}.bar{height:7px;background:#eee;border-radius:6px;margin:12px 0}.bar i{display:block;background:#74937d;height:100%;border-radius:6px}.layout{display:grid;grid-template-columns:1.05fr 1fr;gap:24px}.message{border-top:1px solid var(--line);padding:18px 0}.message h3{margin:0 0 8px}pre{white-space:pre-wrap;font:14px system-ui;line-height:1.7}.reason{color:#a1482e}.badge{background:#edf1e8;border-radius:20px;padding:3px 10px;font-size:12px}button,select,input{font:inherit;padding:9px 12px;border:1px solid #b7c2b8;border-radius:6px;background:white}button{cursor:pointer}button.primary{background:var(--green);color:white}button:disabled{opacity:.4;cursor:not-allowed}table{width:100%;border-collapse:collapse;font-size:13px}td,th{text-align:left;padding:12px 6px;border-bottom:1px solid var(--line)}#notice{position:sticky;top:8px;background:#ffedcc;padding:12px;display:none;z-index:2}details{margin-top:24px}li{margin:8px 0}@media(max-width:850px){.layout{grid-template-columns:1fr}header{display:block}.panel{overflow:auto}}
</style><header><div><small style="color:#dce4d7">THE HOME BAKERY / ORDER DESK</small><h1>Butter & Batch</h1><div>A little order for your busiest baking days.</div></div><a href="/README.html" target="_blank">How to use this app ↗</a></header>
<main><div id="notice" role="alert"></div><div class="toolbar"><b>Working day</b><select id="day" aria-label="Working day"></select><button onclick="act({action:'day',day:document.getElementById('day').value})">Advance day</button><span class="muted">November 23–29, 2026 · Pickups at 5 PM</span></div><p class="muted">Two days’ notice · 8 oven hours daily · Helper: +4 hours for $100 · Cupcakes $40/dozen (½ hour) · Cakes $120 (2 hours)</p>
<div class="calendar" id="calendar"></div><div class="layout"><section class="panel"><h2>Instagram inbox <span id="pending" class="badge"></span></h2><p class="muted">You decide each request. Capacity updates after every decision.</p><label><input type="checkbox" id="history" onchange="render()"> Show decided messages</label><div id="inbox"></div></section><section class="panel"><h2>Order book</h2><label>Search customer <input id="search" oninput="renderOrders()" placeholder="Customer name"></label><div id="orders"></div><p class="muted">Revenue less helper cost excludes ingredients and other costs; it is not profit.</p></section></div><details class="panel"><summary>Decision history</summary><ul id="audit"></ul></details></main>
<script>
let data;const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));const date=s=>new Date(s+'T12:00:00').toLocaleDateString('en-CA',{weekday:'short',month:'short',day:'numeric'});const money=n=>'$'+n;
async function load(){data=await(await fetch('/api/state')).json();render()}
async function act(a){try{let r=await fetch('/api/action',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(a)});let j=await r.json();if(!r.ok)throw Error(j.error);await load();document.getElementById('notice').style.display='none'}catch(e){let n=document.getElementById('notice');n.textContent=e.message;n.style.display='block'}}
function render(){document.getElementById('day').innerHTML=Array.from({length:7},(_,i)=>'2026-11-'+(23+i)).map(d=>`<option ${d===data.today?'selected':''} ${d<data.today?'disabled':''}>${d}</option>`).join('');document.getElementById('calendar').innerHTML=data.calendar.map(d=>`<article class="card"><b>${date(d.day)}</b><strong>${d.hours} <small>/ ${d.capacity} h</small></strong><div class="bar"><i style="width:${d.hours/d.capacity*100}%"></i></div><div>${money(d.revenue)} orders</div><small>${money(d.net)} after helper</small><p>${d.helper?'<span class="badge">Helper booked</span>':`<button ${(new Date(d.day)-new Date(data.today))/86400000<2?'disabled':''} onclick="if(confirm('Book a helper for ${date(d.day)} for $100?'))act({action:'helper',day:'${d.day}'})">+ Helper · $100</button>`}</p></article>`).join('');let pending=data.messages.filter(m=>m.status==='pending');document.getElementById('pending').textContent=pending.length+' pending';let ms=document.getElementById('history').checked?data.messages:pending;document.getElementById('inbox').innerHTML=ms.map(m=>`<article class="message"><h3>${esc(m.customer)} <span class="badge">${esc(m.kind)} · ${esc(m.status)}</span></h3><small>Received ${date(m.day)}</small><pre>${esc(m.raw)}</pre><p class="${m.reason?'reason':'muted'}">${esc(m.reason||'Eligible within notice and capacity rules.')}</p>${m.status==='pending'?`<button class="primary" ${m.reason?'disabled':''} onclick="act({action:'accept',id:${m.id}})">${m.kind==='new'?'Accept order':'Approve '+m.kind}</button> <button onclick="act({action:'reject',id:${m.id}})">Reject</button>`:''}</article>`).join('')||'<p>All caught up. Advance the working day to see the next messages.</p>';renderOrders();document.getElementById('audit').innerHTML=data.audit.map(a=>`<li>${esc(a.day)} · ${esc(a.detail)}</li>`).join('')||'<li>No decisions yet.</li>'}
function renderOrders(){let q=document.getElementById('search').value.toLowerCase();document.getElementById('orders').innerHTML='<table><thead><tr><th>Order / customer</th><th>Product</th><th>Pickup</th><th>Status</th></tr></thead><tbody>'+data.orders.filter(o=>o.customer.toLowerCase().includes(q)).map(o=>`<tr><td>#${o.id} ${esc(o.customer)}</td><td>${o.quantity} ${o.product==='cake'?'cake(s)':'dozen cupcakes'}</td><td>${date(o.pickup)}</td><td>${esc(o.status)}</td></tr>`).join('')+'</tbody></table>'}load();
</script></html>'''

class Handler(BaseHTTPRequestHandler):
    def reply(self,code,body,typ='application/json'):
        payload=(json.dumps(body) if typ=='application/json' else body).encode()
        self.send_response(code);self.send_header('Content-Type',typ+'; charset=utf-8');self.send_header('Content-Length',str(len(payload)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(payload)
    def do_GET(self):
        if self.path=='/': self.reply(200,PAGE,'text/html')
        elif self.path=='/README.html': self.reply(200,(ROOT/'README.html').read_text(),'text/html')
        elif self.path=='/api/state':
            with connect() as c:self.reply(200,state(c))
        else:self.reply(404,{'error':'Not found'})
    def do_POST(self):
        if self.path!='/api/action':self.reply(404,{'error':'Not found'});return
        if self.headers.get('Origin') not in (None,'http://127.0.0.1:8000','http://localhost:8000'):self.reply(403,{'error':'Origin not allowed'});return
        try:
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<8192:raise ValueError('Invalid request size.')
            a=json.loads(self.rfile.read(length))
            with connect() as c:
                c.execute('BEGIN IMMEDIATE');action(c,a)
            self.reply(200,{'ok':True})
        except (ValueError,KeyError,TypeError,sqlite3.IntegrityError) as e:self.reply(400,{'error':str(e)})

if __name__=='__main__':
    init()
    print('Bakery app: http://127.0.0.1:8000 — keep this window open. Ctrl+C stops it.',flush=True)
    ThreadingHTTPServer(('127.0.0.1',8000),Handler).serve_forever()
